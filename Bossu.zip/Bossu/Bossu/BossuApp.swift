//
//  BossuApp.swift
//  Bossu
//
//  Created by Capatina Ionut on 12.02.2024.
//

import SwiftUI

@main
struct BossuApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
