//
//  ContentView.swift
//  Bossu
//
//  Created by Capatina Ionut on 12.02.2024.
//
import CoreMotion
import SwiftUI

class MotionManager: ObservableObject {
    private let motionManager = CMMotionManager()
    @Published var x = 0.0
    @Published var y = 0.0
    
    init() {
        motionManager.startDeviceMotionUpdates(to: .main) { [weak self] data, error in

            guard let motion = data?.attitude else { return }
            self?.x = motion.roll
            self?.y = motion.pitch
        }
    }
}
struct ContentView: View {
    @StateObject private var motion = MotionManager()
    @State var cul1 = 1
    @State var cul2 = 1
    @State var culchange = false
    var body: some View {
        VStack {
            Button{
                withAnimation(.linear(duration: 5)){
                    culchange.toggle()
                }
            }label: {
                Text("DICTEAZA")
                    .font(.largeTitle)
                    .bold()
                    .foregroundStyle(AngularGradient(colors: [culchange ? .yellow : .white,.white.opacity(0.6),.white,.white.opacity(0.4),.white,.white.opacity(0.25),.white], center: .center, startAngle: .degrees(25), endAngle: .degrees(360)))
            }
            .padding(20)
            .background(AngularGradient(colors: [culchange ? .yellow.opacity(0.85) : .yellow, culchange ? .yellow.opacity(0.4) : .yellow.opacity(0.6),.yellow,.yellow.opacity(0.4),.yellow,.yellow.opacity(0.25),.yellow], center: .center, startAngle: .degrees(25), endAngle: .degrees(360)))
            .clipShape(RoundedRectangle(cornerRadius: 20))
            .rotation3DEffect(.degrees(motion.x * 20), axis: (x: 0, y: 1, z: 0))
            .rotation3DEffect(.degrees(motion.y * 20), axis: (x: -1, y: 0, z: 0))
            .shadow(color: culchange ? .yellow : .black, radius: culchange ? 153.3 : 5.5)
        }
        .padding(40)
    }
}

#Preview {
    ContentView()
}
