//
//  CreateAccountView.swift
//  CofetariaDamarin
//
//  Created by Capatina Ionut on 31.01.2024.
//

import SwiftUI
import FirebaseCore
import FirebaseAuth
import FirebaseFirestore

struct CreateAccountView: View {
    @AppStorage("accountExist") var accountNotExist = false
    @State private var email: String = ""
    @State private var password: String = ""
    @State private var nume: String = ""
    @State var nume1 = "nume1"
    @State private var isLoading = false
    @FocusState var isNameFocused:Bool
    @State private var paddingtxtfield = 20.0
    
    var body: some View {
        if (accountNotExist){
            NavigationStack{
                VStack{
                    if isNameFocused{
                        Spacer()
                            .padding(.top, 100)
                    }else{
                        HStack{
                            Text("Creaza cont pentru a putea continua cumparaturile")
                                .font(.headline)
                        }
                    }
                    HStack{
                        TextField("UserName", text: $nume)
                            .padding()
                            .frame(height: 50)
                            .background(.gray.opacity(0.2))
                            .clipShape(Capsule())
                            .overlay(Capsule().stroke(lineWidth: 0.8).opacity(0.9))
                            .foregroundStyle(.black)
                            .textInputAutocapitalization(.never)
                            .focused($isNameFocused)
                    }.padding()
                    HStack{
                        TextField("Email", text: $email)
                            .padding()
                            .frame(height: 50)
                            .background(.gray.opacity(0.2))
                            .clipShape(Capsule())
                            .overlay(Capsule().stroke(lineWidth: 0.8).opacity(0.9))
                            .foregroundStyle(.black)
                            .textInputAutocapitalization(.never)
                            .focused($isNameFocused)
                    }.padding()
                    HStack{
                        SecureField("Password", text: $password)
                            .padding()
                            .frame(height: 50)
                            .background(.gray.opacity(0.2))
                            .clipShape(Capsule())
                            .overlay(Capsule().stroke(lineWidth: 0.8).opacity(0.9))
                            .foregroundStyle(.black)
                            .textInputAutocapitalization(.never)
                            .focused($isNameFocused)
                    }.padding()
                    
                    //Button inregistrare
                    HStack(alignment: .bottom){
                        Button{
                            Auth.auth().createUser(withEmail: email, password: password){
                                (result, error) in
                                if error != nil {
                                    print(error?.localizedDescription ?? "")
                                    withAnimation{
                                        isLoading.toggle()
                                    }
                                } else {
                                    let db = Firestore.firestore()
                                    let data: [String: Any] = [
                                        "UserName: ": nume,
                                        "Email": email,
                                    ]
                                    
                                    //Now we add same user and email to local memory so we don't need to sync every time
                                    UserDefaults.standard.setValue(result?.user.uid, forKey: "UID")
                                    //UID is unique key
                                    
                                    UserDefaults.standard.setValue(nume, forKey: "NAME")
                                    UserDefaults.standard.setValue(email, forKey: "EMAIL")
                                    
                                    db.collection("USERS").addDocument(data: data)
                                    isLoading.toggle()
                                    self.accountNotExist = false
                                }
                            }
                        }label: {
                            if isLoading{
                                ProgressView()
                                    .colorScheme(.dark)
                            }else{
                                Text("Inregistrare")
                                    .font(.title2)
                                //.controlSize(.large)
                                //.frame(width: .infinity,height: 30)
                            }
                        }.frame(width: 200,height: 30)
                            .padding()
                            .foregroundStyle(.white)
                            .background(Color.black)
                            .cornerRadius(15)
                    }
                    if isNameFocused{
                        Spacer()
                    }else{
                        
                    }
                    HStack{
                        Button{
                            withAnimation(.easeInOut(duration: 2)){
                                self.accountNotExist = false
                            }
                        }label: {
                            Text("Aveti deja cont?")
                                .foregroundStyle(.black)
                            Text("Logare")
                                .fontWeight(.bold)
                                .foregroundStyle(.mint)
                        }
                    }
                }
            }.preferredColorScheme(.light)
                .padding()
        }
        else{
            LoginView()
        }
    }
}

#Preview {
    CreateAccountView()
}
