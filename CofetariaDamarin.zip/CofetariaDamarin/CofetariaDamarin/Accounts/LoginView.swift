//
//  LoginView.swift
//  CofetariaDamarin
//
//  Created by Capatina Ionut on 31.01.2024.
//

import SwiftUI
import FirebaseCore
import FirebaseAuth
import FirebaseFirestore
import _AuthenticationServices_SwiftUI

struct LoginView: View {
    //@State private var signEmail = false
    @State private var email: String = ""
    @State private var password: String = ""
    @State private var nume: String = ""
    @AppStorage("accountExist") var accountNotExist = false
    @AppStorage("logat") var logat = true
    @State var nume1 = "nume1"
    @State private var isLoading = false
    @State private var isSignedIn = false
    var body: some View {
        if accountNotExist{
            CreateAccountView()
        }else{
            if logat{
                HomeView()
            }else{
                NavigationStack{
                    GeometryReader{ geometry in
                        VStack{
                            Spacer()
                            HStack{
                                Text("Autentificare")
                                    .font(.headline)
                            }
                            HStack{
                                TextField("Email", text: $email)
                                    .padding()
                                    .frame(height: 50)
                                    .background(.gray.opacity(0.2))
                                    .clipShape(Capsule())
                                    .overlay(Capsule().stroke(lineWidth: 0.8).opacity(0.9))
                                    .foregroundStyle(.black)
                                    .textInputAutocapitalization(.never)
                            }.padding()
                            HStack{
                                SecureField("Parola", text: $password)
                                    .padding()
                                    .frame(height: 50)
                                    .background(.gray.opacity(0.2))
                                    .clipShape(Capsule())
                                    .overlay(Capsule().stroke(lineWidth: 0.8).opacity(0.9))
                                    .foregroundStyle(.black)
                                    .navigationBarBackButtonHidden()
                                    .textInputAutocapitalization(.never)
                            }.padding()
                                .padding(.bottom, 50)
                            
                            //LOGIN BUTTON
                            
                            HStack(alignment: .bottom){
                                Button{
                                    isLoading = true
                                    Auth.auth().signIn(withEmail: email, password: password){
                                        (result, error) in
                                        if error != nil{
                                            print(error?.localizedDescription ?? "")
                                            withAnimation{
                                                isLoading.toggle()
                                            }
                                        } else {
                                            // Now we collect user information and move next view
                                            logat = true
                                            let db = Firestore.firestore()
                                            db.collection("USERS").document(result?.user.uid ?? "").getDocument {
                                                document , error in
                                                
                                                if let document = document, document.exists {
                                                    let name = document.get("UserName") as? String ?? ""
                                                    let email = document.get("Email") as? String ?? ""
                                                    
                                                    //Now we store collected name and email from firestore to local storage
                                                    UserDefaults.standard.set(name, forKey: "NAME")
                                                    UserDefaults.standard.set(email, forKey: "EMAIL")
                                                    
                                                    isLoading.toggle()
                                                }
                                                else{
                                                    isLoading.toggle()
                                                    print("Document not exist")
                                                }
                                            }
                                            
                                        }
                                    }
                                }label: {
                                    if isLoading{
                                        ProgressView()
                                            .colorScheme(.dark)
                                    }else{
                                        Text("Conectati-va")
                                            .font(.title2)
                                        //.controlSize(.large)
                                            .frame(width: geometry.size.width ,height: 30)
                                    }
                                }.frame(width: 200,height: 30)
                                    .padding()
                                    .foregroundStyle(.white)
                                    .background(Color.black)
                                    .cornerRadius(15)
                            }
                            VStack{
                                Divider()
                            }.foregroundColor(.black)
                            HStack{
                                Spacer()
                                Text(" sau ")
                                    .foregroundStyle(.mint)
                                Spacer()
                            }
                            VStack{
                                Divider()
                            }
                            HStack{
                                SignInWithAppleButton{ request in
                                    //
                                } onCompletion: { result in
                                    //
                                }
                                .frame(width: geometry.size.width ,height: 50)
                                .cornerRadius(10)
                            }
                            Spacer()
                            HStack{
                                Button{
                                        self.accountNotExist = true
                                }label: {
                                    Text("Nu ai cont?")
                                        .foregroundStyle(.black)
                                    Text("Creează-ți cont")
                                        .fontWeight(.bold)
                                        .foregroundStyle(.mint)
                                }
                            }
                        }.background(Color(.white))
                    }.padding()
                }
            }
        }
    }
}

#Preview {
    LoginView()
}
