//
//  AppleAuthViewModel.swift
//  CofetariaDamarin
//
//  Created by Capatina Ionut on 01.02.2024.
//

import SwiftUI

struct AppleAuthViewModel: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

#Preview {
    AppleAuthViewModel()
}
