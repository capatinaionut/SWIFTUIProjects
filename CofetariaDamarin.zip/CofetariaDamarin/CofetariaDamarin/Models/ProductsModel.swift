//
//  ProductsModel.swift
//  CofetariaDamarin
//
//  Created by Capatina Ionut on 02.02.2024.
//

import Foundation
import Swift

struct ProductsModel: Identifiable {
    var id = UUID()
    var name: String
    var image: String
    var categorie: String
    var description: String
    var price: Int
}

var productList = [
    ProductsModel(name: "Tort Savoy 1", image: "tort1", categorie: "torturi", description: "Blat pufos ciocolata, umplutura ciocolata si frisca vegetala, topping martipan", price: 250),
    ProductsModel(name: "Tort Savoy 2", image: "tort2", categorie: "torturi", description: "Blat pufos ciocolata, umplutura ciocolata si frisca vegetala, topping martipan", price: 350),
    ProductsModel(name: "Tort Savoy 3", image: "tort3", categorie: "torturi", description: "Blat pufos ciocolata, umplutura ciocolata si frisca vegetala, topping martipan", price: 300),
    ProductsModel(name: "Tort Savoy 4", image: "tort4", categorie: "torturi", description: "Blat pufos ciocolata, umplutura ciocolata si frisca vegetala, topping martipan", price: 270),
    ProductsModel(name: "Tort Savoy 5", image: "tort5", categorie: "torturi", description: "Blat pufos ciocolata, umplutura ciocolata si frisca vegetala, topping martipan", price: 420),
    ProductsModel(name: "Tort Savoy 7", image: "tort6", categorie: "torturi", description: "Blat pufos ciocolata, umplutura ciocolata si frisca vegetala, topping martipan", price: 220),
    ProductsModel(name: "Tort Savoy 8", image: "tort7", categorie: "torturi", description: "Blat pufos ciocolata, umplutura ciocolata si frisca vegetala, topping martipan", price: 310),
    ProductsModel(name: "Tort Savoy 9", image: "tort8", categorie: "torturi", description: "Blat pufos ciocolata, umplutura ciocolata si frisca vegetala, topping martipan", price: 300),
    ProductsModel(name: "Tort Savoy 10", image: "tort9", categorie: "torturi", description: "Blat pufos ciocolata, umplutura ciocolata si frisca vegetala, topping martipan", price: 250),
    ProductsModel(name: "Prajitura 1", image: "prajitura1", categorie: "prajituri", description: "Prajitura 1mmm", price: 25),
    ProductsModel(name: "Prajitura 2", image: "prajitura2", categorie: "prajituri", description: "Prajitura 1mmm", price: 35),
    ProductsModel(name: "Prajitura 3", image: "prajitura3", categorie: "prajituri", description: "Prajitura 1mmm", price: 15),
    ProductsModel(name: "Prajitura 4", image: "prajitura4", categorie: "prajituri", description: "Prajitura 1mmm", price: 30),
    ProductsModel(name: "Prajitura 5", image: "prajitura5", categorie: "prajituri", description: "Prajitura 1mmm", price: 30),
    ProductsModel(name: "Mix praline 1", image: "speciale1", categorie: "specialitati", description: "Mix praline 1", price: 120),
    ProductsModel(name: "Mix praline 2", image: "speciale2", categorie: "specialitati", description: "Mix praline 1", price: 70),
    ProductsModel(name: "Mix praline 3", image: "speciale3", categorie: "specialitati", description: "Mix praline 1", price: 160),
    ProductsModel(name: "Mix praline 4", image: "speciale4", categorie: "specialitati", description: "Mix praline 1", price: 150),
   
    
]
