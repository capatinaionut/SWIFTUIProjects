//
//  CosCumparaturiView.swift
//  CofetariaDamarin
//
//  Created by Capatina Ionut on 05.02.2024.
//

import SwiftUI

struct CosCumparaturiView: View {
    @EnvironmentObject var cosManager: CosManager
    var body: some View {
        ScrollView{
            if cosManager.produse.count > 0{
                ForEach(cosManager.produse, id: \.id){
                    prod in
                    ProdCosCumparaturi(produs: prod)
                }
                HStack{
                    Text("Total:")
                    Spacer()
                    Text("\(cosManager.total) RON")
                        .bold()
                }
                .padding()
            }else{
                Text("Cosul tau este gol")
            }
        }
        .navigationTitle(Text("Cosul meu"))
        .padding(.top)
    }
}

#Preview {
    CosCumparaturiView()
        .environmentObject(CosManager())
}
