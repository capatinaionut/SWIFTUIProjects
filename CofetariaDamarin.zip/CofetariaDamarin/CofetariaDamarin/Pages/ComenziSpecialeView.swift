//
//  ComenziSpecialeView.swift
//  CofetariaDamarin
//
//  Created by Capatina Ionut on 26.01.2024.
//

import SwiftUI

struct ComenziSpecialeView: View {
    @State private var isShowing = false
    @State private var isShowing1 = false
    @State private var isShowing2 = false
    @State private var animatAmount = 1.0
    @State private var animatAmount1 = 1.0
    @State private var animatAmount2 = 1.0
    //image
    var body: some View {
        NavigationStack{
            VStack{
                HStack{
                    Spacer()
                    Button{
                        print("1")
                        isShowing.toggle()
                        if(isShowing==true){
                            isShowing1 = false
                            isShowing2 = false
                            animatAmount1 = 1.0
                            animatAmount2 = 1.0
                            animatAmount = 1.3
                        }else{
                            animatAmount = 1
                        }
                    }label: {
                        Image(systemName: "party.popper")
                            .imageScale(.large)
                        //.scaledToFit()
                            .foregroundStyle(.black)
                            .overlay(Circle().frame(width: 45,height: 45).padding().foregroundStyle(isShowing ? .mint : .gray).opacity(0.3))
                            .scaleEffect(CGSize(width: 1.0 * Double(animatAmount), height: 1.0 * Double(animatAmount)))
                            .transition(.move(edge: .top))
                    }.animation(.snappy, value: isShowing)
                    Spacer()
                    Button{
                        print("2")
                        isShowing1.toggle()
                        if(isShowing1==true){
                            isShowing = false
                            isShowing2 = false
                            animatAmount = 1.0
                            animatAmount2 = 1.0
                            animatAmount1 = 1.3
                        }else{
                            animatAmount1 = 1
                        }
                    }label: {
                        Image(systemName: "party.popper")
                            .imageScale(.large)
                        //.scaledToFit()
                            .foregroundStyle(.black)
                            .overlay(Circle().frame(width: 45,height: 45).padding().foregroundStyle(isShowing1 ? .mint : .gray).opacity(0.3))
                            .scaleEffect(CGSize(width: 1.0 * Double(animatAmount1), height: 1.0 * Double(animatAmount1)))
                            .transition(.move(edge: .top))
                    }.animation(.snappy, value: isShowing1)
                    Spacer()
                    Button{
                        print("3")
                        isShowing2.toggle()
                        if(isShowing2==true){
                            isShowing = false
                            isShowing1 = false
                            animatAmount = 1.0
                            animatAmount1 = 1.0
                            animatAmount2 = 1.3
                        }else{
                            animatAmount2 = 1
                        }
                    }label: {
                        Image(systemName: "party.popper")
                            .imageScale(.large)
                        //.scaledToFit()
                            .foregroundStyle(.black)
                            .overlay(Circle().frame(width: 45,height: 45).padding().foregroundStyle(isShowing2 ? .mint : .gray).opacity(0.3))
                            .scaleEffect(CGSize(width: 1.0 * Double(animatAmount2), height: 1.0 * Double(animatAmount2)))
                            .transition(.move(edge: .top))
                    }.animation(.snappy, value: isShowing2)
                    Spacer()
                }
                .padding().overlay(RoundedRectangle(cornerSize: CGSize(width: 20, height: 40)).foregroundStyle(.gray).opacity(0.2))
                Spacer()
                NavigationLink(destination: withAnimation {UploadImage()}) {
                    Text("Upload image")
                }
            }.padding()
        }
    }
}

#Preview {
    ComenziSpecialeView()
}
