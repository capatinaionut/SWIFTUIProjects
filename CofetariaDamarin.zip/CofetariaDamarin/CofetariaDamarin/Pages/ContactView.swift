//
//  ContactView.swift
//  CofetariaDamarin
//
//  Created by Capatina Ionut on 25.01.2024.
//

import MapKit
import SwiftUI

struct ContactView: View {
    @State var locatie1 = MKCoordinateRegion(
        center: .init(latitude: 44.31611,longitude: 23.81472),
        span: .init(latitudeDelta: 0.003, longitudeDelta: 0.003))
    @State var locatie2 = MKCoordinateRegion(
        center: .init(latitude: 44.33739,longitude: 23.78076),
        span: .init(latitudeDelta: 0.003, longitudeDelta: 0.003))
    @State var locatie3 = MKCoordinateRegion(
        center: .init(latitude: 44.32442,longitude: 23.81904),
        span: .init(latitudeDelta: 0.003, longitudeDelta: 0.003))
    
    var body: some View {
        GeometryReader{ geo in
            ScrollView{
                VStack{
                    VStack{
                        VStack{
                            Button{
                                if let yourURL = URL(string: "http://maps.apple.com/?q=44,31611° N, 23,81472° E") {
                                       UIApplication.shared.open(yourURL, options: [:], completionHandler: nil)
                                   }
                            }label: {
                                HStack{
                                    Image("locatie3")
                                        .resizable()
                                        .scaledToFit()
                                        .cornerRadius(30)
                                        .padding()
                                }
                            }
                            Text("Strada Horia 16, Craiova")
                                .font(.headline)
                                .fontWeight(.medium)
                        }
                        HStack{
                            Text("Phone:")
                                .font(.title2)
                                .padding()
                            Image(systemName: "phone")
                                .imageScale(.large)
                                .padding(5)
                                .foregroundColor(.mint)
                                .background(.gray)
                                .cornerRadius(40)
                            Link("0351 177 271", destination: URL(string: "tel:0351177 271")!).foregroundColor(.mint).font(.title2)
                        }
                    }.overlay(RoundedRectangle(cornerSize: CGSize(width: 20, height: 10)).frame(width: geo.size.width / 1,height: geo.size.height / 1).foregroundStyle(.gray).opacity(0.1))
                        .cornerRadius(30)
                        .shadow(radius: 10)
                    Divider()
                    VStack{
                        VStack{
                            Button{
                                if let yourURL1 = URL(string: "http://maps.apple.com/?q=44,33797° N, 23,78156° E") {
                                       UIApplication.shared.open(yourURL1, options: [:], completionHandler: nil)
                                   }
                            }label: {
                                HStack{
                                    Image("locatie1")
                                        .resizable()
                                        .scaledToFit()
                                        .cornerRadius(30)
                                        .padding()
                                }
                            }
                            Text("Bulevardul Oltenia 9, Craiova")
                                .font(.headline)
                                .fontWeight(.medium)
                                .fontWeight(.medium)
                        }
                        HStack{
                            Text("Phone:")
                                .font(.title2)
                                .padding()
                            Image(systemName: "phone")
                                .imageScale(.large)
                                .padding(5)
                                .foregroundColor(.mint)
                                .background(.gray)
                                .cornerRadius(40)
                            Link("0251 586 284", destination: URL(string: "tel:0251586284")!).foregroundColor(.mint).font(.title2)
                        }
                    }.overlay(RoundedRectangle(cornerSize: CGSize(width: 20, height: 10)).frame(width: geo.size.width / 1,height: geo.size.height / 1).foregroundStyle(.gray).opacity(0.1))
                        .cornerRadius(30)
                        .shadow(radius: 10)
                    Divider()
                    VStack{
                        VStack{
                            Button{
                                if let yourURL2 = URL(string: "http://maps.apple.com/?q=44,32442° N, 23,81905° E") {
                                       UIApplication.shared.open(yourURL2, options: [:], completionHandler: nil)
                                   }
                            }label: {
                                HStack{
                                    Image("locatie2")
                                        .resizable()
                                        .scaledToFit()
                                        .cornerRadius(30)
                                        .padding()
                                }
                            }
                            Text("Strada Maramureș 26A, Craiova")
                                .font(.headline)
                                .fontWeight(.medium)
                                .fontWeight(.medium)
                        }
                        HStack{
                            Text("Phone:")
                                .font(.title2)
                                .padding()
                            Image(systemName: "phone")
                                .imageScale(.large)
                                .padding(5)
                                .foregroundColor(.mint)
                                .background(.gray)
                                .cornerRadius(40)
                            Link("0760 174 938", destination: URL(string: "tel:0760174938")!).foregroundColor(.mint).font(.title2)
                        }
                    }.overlay(RoundedRectangle(cornerSize: CGSize(width: 20, height: 10)).frame(width: geo.size.width / 1,height: geo.size.height / 1).foregroundStyle(.gray).opacity(0.1))
                        .cornerRadius(30)
                        .shadow(radius: 10)
                    
                }
            }.scrollIndicators(.hidden)
        }.padding()
    }
}

#Preview {
    ContactView()
}
