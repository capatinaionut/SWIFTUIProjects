//
//  TortViewTest.swift
//  CofetariaDamarin
//
//  Created by Capatina Ionut on 05.02.2024.
//

import SwiftUI

struct TortViewTest: View {
    @State var torturi = [0:"Faboulous Cake",1:"Aniversar fistic flower",2:"Champange Sweet"]
    @State var position = [1]
    @State var cosCumparaturi = [""]
    @EnvironmentObject var cosManager: CosManager
    //var produs: ProductsModel
    
    var body: some View {
        GeometryReader{ geometry in
            ScrollView{
                    ForEach(productList, id: \.id){ prod in
                        if(prod.categorie == "torturi"){
                            ProductsView(produs: prod).environmentObject(cosManager)
                            /*
                             Image("\(produs.image)")
                             .resizable()
                             .frame(width: geometry.size.width / 1,height: geometry.size.height / 1.5)
                             .scaledToFit()
                             .cornerRadius(30)
                             .shadow(radius: 7)
                             Spacer()
                             VStack{
                             Text("\(produs.name)")
                             .font(.title2)
                             .fontWeight(.semibold)
                             //.padding()
                             Text("\(produs.description)")
                             Spacer()
                             HStack{
                             Text("Pret: ")
                             .font(.headline)
                             Text("\(produs.price) RON")
                             .font(.headline)
                             Button{
                             }label: {
                             Image(systemName: "cart.circle")
                             .imageScale(.large)
                             .foregroundStyle(.black)
                             Text("Adauga in cos")
                             .font(.headline)
                             .foregroundStyle(.black)
                             }.foregroundStyle(.black)
                             .background(.clear)
                             //.clipShape(RoundedRectangle(cornerRadius: 25))
                             .padding(5).overlay(
                             RoundedRectangle(cornerSize: CGSize(width: 20, height: 20))
                             .trim()
                             .stroke(.black).background(.gray).opacity(0.2).cornerRadius(20)
                             )
                             .padding(.trailing,10)
                             .shadow(color: .black,radius: 20)
                             }
                             .padding(.top,20)
                             }*/
                        }
                }
                /*.toolbar{
                 Button{
                 
                 }label: {
                 Image(systemName: "arrow.up.circle")
                 .imageScale(.large)
                 .foregroundStyle(.black)
                 .background(.blue)
                 .frame(width: 50,height: 50)
                 }
                 }*/
            }.environmentObject(cosManager)
        }.padding()
            .ignoresSafeArea()
    }
}

#Preview {
    TortViewTest().environmentObject(CosManager())
}
