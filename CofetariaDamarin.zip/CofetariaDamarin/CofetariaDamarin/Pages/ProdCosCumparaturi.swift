//
//  CosCumparaturi.swift
//  CofetariaDamarin
//
//  Created by Capatina Ionut on 05.02.2024.
//

import SwiftUI

struct ProdCosCumparaturi: View {
    @EnvironmentObject var cosManager: CosManager
    var produs: ProductsModel
    var body: some View {
        VStack{
            HStack(spacing: 20){
                Image(produs.image)
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .frame(width: 70)
                    .cornerRadius(9)
                
                VStack(alignment: .leading, spacing: 5){
                    Text(produs.name)
                        .bold()
                    
                    Text("\(produs.price) RON")
                        .bold()
                }.padding()
                
                Spacer()
                
                Image(systemName: "trash")
                    .foregroundColor(.red)
                    .onTapGesture {
                        cosManager.removeFromCart(produs: produs)
                    }
            }
            .padding(.horizontal)
        }
    }
}

#Preview {
    ProdCosCumparaturi(produs: productList[2])
        .environmentObject(CosManager())
}
