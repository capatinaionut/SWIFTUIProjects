//
//  TorturiView.swift
//  CofetariaDamarin
//
//  Created by Capatina Ionut on 25.01.2024.
//

import SwiftUI

struct TorturiView: View {
    @State var torturi = [0:"Faboulous Cake",1:"Aniversar fistic flower",2:"Champange Sweet"]
    @State var position = [1]
    @State var cosCumparaturi = [""]
    @EnvironmentObject var cosManager: CosManager
    
    var body: some View {
        GeometryReader{ geometry in
                    ScrollView{
                        ForEach(1..<35){ tort in
                            VStack{
                                Image("tort\(tort)")
                                    .resizable()
                                    .frame(width: geometry.size.width / 1,height: geometry.size.height / 1.5)
                                    .scaledToFit()
                                    .cornerRadius(30)
                                    .shadow(radius: 7)
                                Spacer()
                                VStack{
                                    Text("Tort \(torturi[tort] ?? "\(tort)")")
                                        .font(.title2)
                                        .fontWeight(.semibold)
                                    //.padding()
                                    Text("Blat pufos ciocolata, umplutura ciocolata si frisca vegetala, topping martipan.")
                                    Spacer()
                                    HStack{
                                        Text("Pret: ")
                                            .font(.headline)
                                        Text("255 RON")
                                            .font(.headline)
                                        Button{
                                            
                                        }label: {
                                            Image(systemName: "cart.circle")
                                                .imageScale(.large)
                                                .foregroundStyle(.black)
                                            Text("Adauga in cos")
                                                .font(.headline)
                                                .foregroundStyle(.black)
                                        }.foregroundStyle(.black)
                                            .background(.clear)
                                            //.clipShape(RoundedRectangle(cornerRadius: 25))
                                            .padding(5).overlay(
                                                RoundedRectangle(cornerSize: CGSize(width: 20, height: 20))
                                                    .trim()
                                                    .stroke(.black).background(.gray).opacity(0.2).cornerRadius(20)
                                            )
                                            .padding(.trailing,10)
                                            .shadow(color: .black,radius: 20)
                                    }
                                    .padding(.top,20)
                                }
                            }.padding(.top,20)
                        }
                    }.scrollIndicators(.hidden)
                    /*.toolbar{
                        Button{
                            
                        }label: {
                            Image(systemName: "arrow.up.circle")
                                .imageScale(.large)
                                .foregroundStyle(.black)
                                .background(.blue)
                                .frame(width: 50,height: 50)
                        }
                    }*/
        }.padding()
            .ignoresSafeArea()
    }
}

#Preview {
    TorturiView()
}
