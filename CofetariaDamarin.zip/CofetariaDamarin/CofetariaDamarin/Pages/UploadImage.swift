//
//  UploadImage.swift
//  CofetariaDamarin
//
//  Created by Capatina Ionut on 12.02.2024.
//

import SwiftUI
import FirebaseStorage

struct UploadImage: View {
    @State var isPickerShowing = false
    @State var selectedImage: UIImage?
    @State var picName = ""
    var body: some View {
        VStack{
            if selectedImage != nil {
                Image(uiImage: selectedImage!)
                    .resizable()
                    .frame(width: 200,height: 200)
            }
            
            Button{
                isPickerShowing = true
            }label: {
                Text("Select a Photo")
            }
            
            //Upload button
            if selectedImage != nil {
                TextField("Image name:", text: $picName)

                Button{
                    //uPLOAD THE IMAGE
                    uploadPhoto()
                }label: {
                    Text("Upload photo")
                }
            }
        }
        .sheet(isPresented: $isPickerShowing, onDismiss: nil){
            //Image picker
            
            ImagePicker(selectedImage: $selectedImage, isPickerShowing: $isPickerShowing)
        }
    }
    
    func uploadPhoto(){
        //make sure the selected image property isn't nil
        guard selectedImage != nil else{
            return
        }
        //create storage reference
        let storageRef = Storage.storage().reference()
        
        //turn our image into data
        let imageData = selectedImage!.jpegData(compressionQuality: 0.8)
        guard imageData != nil else{
            return
        }
        
        //specify the file path and name
        let fileRef = storageRef.child("images/\((picName != "") ? picName : UUID().uuidString).jpg")//with picname
        /*or with autoname
        let fileRef = storageRef.child("images/\(UUID().uuidString).jpg")
         */
        
        //Upload the data
        let uploadTask = fileRef.putData(imageData!, metadata: nil){
            metadata, error in
            
            //check for errors
            if error == nil && metadata != nil{
                
            }
        }
        
    }
}

#Preview {
    UploadImage()
}
