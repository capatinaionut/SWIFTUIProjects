//
//  PrajituriView.swift
//  CofetariaDamarin
//
//  Created by Capatina Ionut on 25.01.2024.
//

import SwiftUI

struct PrajituriView: View {
    @State var prajituri = [0:"Muse",1:"Aniversar fistic flower",2:"Champange Sweet"]
    @State var speciale = [0:"Ciocolate 1",1:"Mix praline 20buc",2:"Mix praline Cesar"]
    
    var body: some View {
        GeometryReader{ geometry in
        ScrollView{
            ForEach(1..<8){ prajitura in
                VStack{
                    Image("prajitura\(prajitura)")
                        .resizable()
                        .frame(width: geometry.size.width / 1,height: geometry.size.height / 1.5)
                        .scaledToFit()
                        .cornerRadius(30)
                        .shadow(radius: 7)
                    Spacer()
                    Text("Prajitura: \(prajituri[prajitura] ?? "\(prajitura)")")
                        .font(.title2)
                        .fontWeight(.semibold)
                        .padding()
                }
            }
            ForEach(1..<7){ special in
                VStack{
                    Image("speciale\(special)")
                        .resizable()
                        .frame(width: geometry.size.width / 1,height: geometry.size.height / 1.5)
                        .clipped()
                        .scaledToFit()
                        .cornerRadius(30)
                        .shadow(radius: 7)
                        .rotation3DEffect(
                            .degrees(25),
                                                  axis: (x: 1.0, y: 0.1, z: 1.0)
                        )
                        
                    Spacer()
                    Text("Specialitate: \(speciale[special] ?? "\(special)")")
                        .font(.title2)
                        .fontWeight(.semibold)
                        .padding()
                }
            }
            }
        }.padding()
            .ignoresSafeArea()
    }
}

#Preview {
    PrajituriView()
}
