//
//  HomeView.swift
//  CofetariaDamarin
//
//  Created by Capatina Ionut on 31.01.2024.
//

import SwiftUI

struct HomeView: View {
    var body: some View {
        VStack{
            Image("damarinlogo")
                .resizable()
                .scaledToFit()
        }.padding()
    }
}

#Preview {
    HomeView()
}
