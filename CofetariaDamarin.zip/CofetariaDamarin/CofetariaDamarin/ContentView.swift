//
//  ContentView.swift
//  CofetariaDamarin
//
//  Created by Capatina Ionut on 24.01.2024.
//

import SwiftUI
import FirebaseCore
import FirebaseAuth

struct ContentView: View {
    @State private var showMenu = false
    @State private var selectedOption: SideMenuOptionModel1?
    @State private var selectedTab = 0
    @State private var selectie = "Acasa"
    @AppStorage("logat") var logat = true
    @AppStorage("logPage") var logPage = false
    @AppStorage("categ") var categ = ""
    @StateObject var cosManager = CosManager()
    //@EnvironmentObject var cosManager: CosManager
    
    var body: some View {
        NavigationStack{
            ZStack {
                TabView(selection: $selectedTab){
                    VStack{
                        //Here if user is nil, mean user not logged in app
                        if Auth.auth().currentUser != nil {
                            if(logat){
                                HomeView()
                            }else if logPage{
                                LoginView()
                            }else{
                                HomeView()
                            }
                        }else{
                                HomeView()
                                    .padding()
                        }
                        /*Image("damarinlogo")
                            .resizable()
                            .scaledToFit()
                         */
                    }
                    .onAppear() {
                        selectie = "Acasa"
                    }.toolbar(.hidden, for: .tabBar)
                        .tag(0)
                    TortViewTest().onAppear() {
                        categ = "Torturi"
                        selectie = "Torturi"
                    }.toolbar(.hidden, for: .tabBar)
                        .tag(1)
                    PrajituriView()
                        .onAppear() {
                            categ = "Prajituri"
                            selectie = "Prajituri"
                        }.toolbar(.hidden, for: .tabBar)
                        .tag(2)
                    ComenziSpecialeView().onAppear() {
                        categ = "Specialitati"
                        selectie = "Comenzi speciale"
                    }.toolbar(.hidden, for: .tabBar)
                        .tag(3)
                    ContactView().onAppear() {
                        selectie = "Contact"
                    }.toolbar(.hidden, for: .tabBar)
                        .tag(4)
                }
                /*VStack{
                    Image("damarinlogo")
                        .resizable()
                        .scaledToFit()
                }*/
                .padding(-10)
                .padding(.bottom, -10)
                SideMenuView(isShowing: $showMenu, selectedTab: $selectedTab)
            }.toolbar(showMenu ? .hidden : .visible, for: .navigationBar)
                .navigationTitle(selectie)
                .navigationBarTitleDisplayMode(.inline)
                .toolbar{
                    ToolbarItem(placement: .topBarLeading){
                        Button{
                            withAnimation{
                                showMenu.toggle()
                            }
                        }label: {
                            HStack{
                                Image(systemName: "line.3.horizontal")
                                    .imageScale(.large)
                                Text("Meniu")
                                    .font(.headline)
                            }
                            .padding(10)
                            .foregroundColor(.white)
                            .background(.black)
                            .cornerRadius(50)
                        }
                    }
                }
            .padding(0)
            .ignoresSafeArea()
        }.preferredColorScheme(.light)
        
    }
}

#Preview {
    ContentView()
        .environmentObject(CosManager())
}
