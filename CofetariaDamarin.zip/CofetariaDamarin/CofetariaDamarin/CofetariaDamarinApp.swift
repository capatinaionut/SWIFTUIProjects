//
//  CofetariaDamarinApp.swift
//  CofetariaDamarin
//
//  Created by Capatina Ionut on 24.01.2024.
//
import FirebaseCore
import SwiftUI

class AppDelegate: NSObject, UIApplicationDelegate {
  func application(_ application: UIApplication,
                   didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey : Any]? = nil) -> Bool {
    FirebaseApp.configure()
    return true
  }
}

@main
struct CofetariaDamarinApp: App {
    @StateObject var cosManager = CosManager()
    // register app delegate for Firebase setup
    @UIApplicationDelegateAdaptor(AppDelegate.self) var delegate
    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(CosManager())
        }
    }
}
