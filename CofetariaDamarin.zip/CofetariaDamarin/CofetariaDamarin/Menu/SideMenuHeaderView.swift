//
//  SideMenuHeaderView.swift
//  CofetariaDamarin
//
//  Created by Capatina Ionut on 24.01.2024.
//

import SwiftUI
import FirebaseCore
import FirebaseAuth
import FirebaseFirestore
import _AuthenticationServices_SwiftUI

struct SideMenuHeaderView: View {
    @AppStorage("logat") var logat = true
    @AppStorage("logPage") var logPage = false
    var body: some View {
        if(logat){
            HStack{
                Button{
                    //
                }label:{
                    Image(systemName: "person.circle.fill")
                        .imageScale(.large)
                        .foregroundStyle(.white)
                        .frame(width: 48, height: 48)
                        .background(.black)
                        .clipShape(RoundedRectangle(cornerRadius: 10))
                        .padding(.vertical)
                }
                VStack(alignment: .leading, spacing: 6){
                    Text("Capatina Ionut")
                        .font(.subheadline)
                    
                    Text("test@gmail.com")
                        .font(.footnote)
                        .tint(.gray)
                }
                Spacer()
                VStack{
                    Button{
                        try? Auth.auth().signOut()
                        logat = false
                    }label: {
                        Text("Iesi din cont")
                            .padding(10)
                            .background(.black)
                            .clipShape(RoundedRectangle(cornerRadius: 20))
                            .foregroundStyle(.white)
                            .font(.caption)
                    }
                    
                }
            }
        }else{
            VStack{
                HStack{
                    Button{
                        logPage.toggle()
                    }label: {
                        Text("Intra in cont")
                            .font(.title3)
                            .padding(10)
                            .background(.black)
                            .clipShape(RoundedRectangle(cornerRadius: 20))
                            .foregroundStyle(.white)
                    }
                }
            }
        }
    }
}

#Preview {
    SideMenuHeaderView()
}
