//
//  SideMenuOptionModel.swift
//  CofetariaDamarin
//
//  Created by Capatina Ionut on 24.01.2024.
//

import Foundation

enum SideMenuOptionModel: Int, CaseIterable{
    case torturi
    case prajituri
    case specialitati
    case comenzispeciale
    case contact
    
    var title: String{
        switch self{
        case .torturi:
            return "Torturi"
        case .prajituri:
            return "Prajituri"
        case .specialitati:
            return "Specialitati"
        case .comenzispeciale:
            return "Comenzi speciale"
        case .contact:
            return "Contact"
        }
    }
    
    var picname: String {
        switch self{
        case .torturi:
            return "torturi"
        case .prajituri:
            return "prajituri"
        case .specialitati:
            return "specialitati"
        case .comenzispeciale:
            return "comenzispeciale"
        case .contact:
            return "contact"
        }
    }
}

extension SideMenuOptionModel: Identifiable{
    var id: Int { return self.rawValue}
}
