//
//  SideMenuOptionModel1.swift
//  CofetariaDamarin
//
//  Created by Capatina Ionut on 24.01.2024.
//

import Foundation

enum SideMenuOptionModel1: Int, CaseIterable{
    case acasa
    case torturi
    case prajituri
    case comenzispeciale
    case contact
    
    var title: String{
        switch self{
        case .acasa:
            return "Acasa"
        case .torturi:
            return "Torturi"
        case .prajituri:
            return "Prajituri"
        case .comenzispeciale:
            return "Comenzi speciale"
        case .contact:
            return "Contact"
        }
    }
    
    var systemImageName: String {
        switch self{
        case .acasa:
            return "house.fill"
        case .torturi:
            return "birthday.cake.fill"
        case .prajituri:
            return "fork.knife"
        case .comenzispeciale:
            return "signature"
        case .contact:
            return "phone"
        }
    }
}

extension SideMenuOptionModel1: Identifiable{
    var id: Int { return self.rawValue}
}
