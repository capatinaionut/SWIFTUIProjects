//
//  CosManager.swift
//  CofetariaDamarin
//
//  Created by Capatina Ionut on 05.02.2024.
//

import Foundation

class CosManager: ObservableObject{
    @Published private(set) var produse: [ProductsModel] = []
    @Published private(set) var total: Int = 0
    
    func addToCart(produs: ProductsModel){
        produse.append(produs)
        total += produs.price
    }
    
    func removeFromCart(produs: ProductsModel){
        produse = produse.filter{ $0.id != produs.id }
        total -= produs.price
    }
}
