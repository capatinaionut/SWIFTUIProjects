//
//  SideMenuRowView.swift
//  CofetariaDamarin
//
//  Created by Capatina Ionut on 24.01.2024.
//

import SwiftUI

struct SideMenuRowView: View {
    //let option: SideMenuOptionModel //GOOD
    let option: SideMenuOptionModel1 //test
    @State private var animationAmount = 1.15
    @Binding var selectedOption: SideMenuOptionModel1?
    private var isSelected: Bool{
        return selectedOption == option
    }
    
    var body: some View {
                HStack{
                        Image(systemName: option.systemImageName)
                            .imageScale(.small)
                            .overlay(
                                Circle()
                                    .trim()
                                    .stroke(isSelected ? .mint : .black)
                                    .padding(-5)
                                   )
                    Text(option.title)
                        .font(.subheadline)
                    Spacer()
                }
                .padding(.leading)
                .frame(height: 44)
                .overlay(RoundedRectangle(cornerSize: CGSize(width: 20, height: 40)).opacity(0.1))
                .foregroundStyle(isSelected ? .mint : .black)
            }
}

#Preview {
    SideMenuRowView(option: .torturi, selectedOption: .constant(.torturi))
}
