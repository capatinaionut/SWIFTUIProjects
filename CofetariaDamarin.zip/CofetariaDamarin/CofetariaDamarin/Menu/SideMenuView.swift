//
//  SideMenuView.swift
//  CofetariaDamarin
//
//  Created by Capatina Ionut on 24.01.2024.
//

import SwiftUI

struct SideMenuView: View {
    @Binding var isShowing: Bool
    @State private var animationAmount = 1.0
    @State private var selectedOption: SideMenuOptionModel1?
    @Binding var selectedTab: Int
    @EnvironmentObject var cosManager: CosManager
    
    var body: some View {
        ZStack{
            if isShowing{
                Rectangle()
                    .opacity(0.2)
                    .onTapGesture {
                        withAnimation{
                            isShowing.toggle()
                            animationAmount = 2
                        }
                    }
                    .cornerRadius(40)
                HStack{
                    VStack(alignment: .leading,spacing: 32){
                        SideMenuHeaderView().padding(.top,20)
                        VStack{
                            NavigationLink(destination: CosCumparaturiView()
                                .environmentObject(CosManager())){
                                HStack{
                                    Image(systemName: "cart")
                                    Text("Cosul meu")
                                }.foregroundStyle(.white)
                                    .padding(6)
                                    .background(.black)
                                    .clipShape(RoundedRectangle(cornerRadius: 15))
                            }
                            /*Button{
                            }label: {
                                HStack{
                                    Image(systemName: "cart")
                                    Text("Cosul meu")
                                }.foregroundStyle(.white)
                                    .padding(6)
                                    .background(.black)
                                    .clipShape(RoundedRectangle(cornerRadius: 15))
                            }*/
                        }
                        VStack{
                            ForEach(SideMenuOptionModel1.allCases){ option in
                                Button{
                                    withAnimation{
                                        onOptionTapped(option)
                                    }
                                }label:{
                                    SideMenuRowView(option: option, selectedOption: $selectedOption)
                                }
                            }
                        }
                        
                        Spacer()
                    }
                    .padding()
                    .frame(width: 270, alignment: .leading)
                    .background(.white)
                    .cornerRadius(40)
                    Spacer()
                }
                .transition(.move(edge: .leading))
                //.transition(.move(edge: .leading).animation(.linear.speed(2)))
                //.animation(.linear, value: isShowing)
            }
        }
        .padding()
        //.transition(.move(edge: .leading).animation(.linear))
        .animation(.snappy, value: isShowing)
        .ignoresSafeArea()
    }
    
    private func onOptionTapped(_ option: SideMenuOptionModel1){
        selectedOption = option
        selectedTab = option.rawValue
        isShowing = false
    }
}

#Preview {
    SideMenuView(isShowing: .constant(true), selectedTab: .constant(0))
}
