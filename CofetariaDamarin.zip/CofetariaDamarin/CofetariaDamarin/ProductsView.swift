//
//  ProductsView.swift
//  CofetariaDamarin
//
//  Created by Capatina Ionut on 24.01.2024.
//

import SwiftUI

struct ProductsView: View {
    @EnvironmentObject var cosManager: CosManager
    var produs: ProductsModel
    var body: some View {
        VStack{
            Image("\(produs.image)")
                .resizable()
                .frame(width: UIScreen.main.bounds.width / 1,height: UIScreen.main.bounds.height / 1.5)
                .scaledToFit()
                .cornerRadius(30)
                .shadow(radius: 7)
            Spacer()
            VStack{
                Text("\(produs.name)")
                    .font(.title2)
                    .fontWeight(.semibold)
                //.padding()
                Text("\(produs.description)")
                Spacer()
                HStack{
                    Text("Pret: ")
                        .font(.headline)
                    Text("\(produs.price) RON")
                        .font(.headline)
                    Button{
                        cosManager.addToCart(produs: produs)
                        print("adaugat")
                    }label: {
                        Image(systemName: "cart.circle")
                            .imageScale(.large)
                            .foregroundStyle(.black)
                        Text("Adauga in cos")
                            .font(.headline)
                            .foregroundStyle(.black)
                    }.foregroundStyle(.black)
                        .background(.clear)
                    //.clipShape(RoundedRectangle(cornerRadius: 25))
                        .padding(5).overlay(
                            RoundedRectangle(cornerSize: CGSize(width: 20, height: 20))
                                .trim()
                                .stroke(.black).background(.gray).opacity(0.2).cornerRadius(20)
                        )
                        .padding(.trailing,10)
                        .shadow(color: .black,radius: 20)
                }
                .padding(.top,20)
            }
        }.padding(.top,20)
    }
}

#Preview {
    ProductsView(produs: productList[0])
        .environmentObject(CosManager())
}
