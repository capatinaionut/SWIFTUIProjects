//
//  ViewController.swift
//  VRU1
//
//  Created by Capatina Ionut on 16.10.2023.
//

import UIKit
import AVFoundation

class ViewController: UIViewController {
    
    @IBOutlet weak var button_invarte: UIButton!
    @IBOutlet weak var text_afisare: UILabel!
    @IBOutlet weak var casuta1: UIImageView!
    @IBOutlet weak var casuta2: UIImageView!
    @IBOutlet weak var casuta3: UIImageView!
    @IBOutlet weak var button_play: UIButton!
    @IBOutlet weak var btnResetare: UIButton!
    @IBOutlet weak var afisare_credit: UILabel!
    
    var index = 0
    var credit = 10
    let linieFull = 10
    let linieMedie = 5
    var valoare1 = 0
    var valoare2 = 0
    var valoare3 = 0
    var player: AVAudioPlayer!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        btnResetare.isEnabled = false
        btnResetare.isHidden = true
        playSound()
        // Do any additional setup after loading the view.
    }

    @IBAction func buttonInvarteActiune(_ sender: Any) {
        if credit > 0{
            index += 1
            invartire()
            afisare_credit.text = "\(credit)"
        }else{
            text_afisare.text = "JOC TERMINAT"
            btnResetare.isHidden = false
            btnResetare.isEnabled = true
        }
    }
    func invartire(){
        roteste1()
        roteste2()
        roteste3()
        if ((valoare1 == 1)&&(valoare2 ==  1)&&(valoare3 == 1)){
                credit += linieFull
            text_afisare.text = "10 PUNCTE" //linie full
        }else if((valoare1 == 1)&&(valoare2 == 1)&&(valoare3 == 2)){
            credit += linieMedie
            text_afisare.text = "5 PUNCTE"
            // c + c + m
        }else if((valoare1 == 1)&&(valoare2 == 1)&&(valoare3 == 3)){
            credit -= 1
            text_afisare.text = "Necastigator"
            //c + c + n
        }else if((valoare1 == 1)&&(valoare2 == 2)&&(valoare3 == 1)){
            credit += linieMedie
            text_afisare.text = "5 PUNCTE"
                //linie castigator, medie, castigator
        }else if((valoare1 == 1)&&(valoare2 == 2)&&(valoare3 == 2)){
            credit -= 1
            text_afisare.text = "Necastigator"
            //c + m + m Necastigator
        }else if((valoare1 == 1)&&(valoare2 == 2)&&(valoare3 == 3)){
            credit -= 1
            text_afisare.text = "Necastigator"
            // c + m + n Necastigator
        }else if((valoare1 == 1)&&(valoare2 == 3)&&(valoare3 == 1)){
            credit -= 1
            text_afisare.text = "Necastigator"
            // c + n + c
        }else if((valoare1 == 1)&&(valoare2 == 3)&&(valoare3 == 2)){
            credit -= 1
            text_afisare.text = "Necastigator"
            // c + n + m
        }else if((valoare1 == 1)&&(valoare2 == 3)&&(valoare3 == 3)){
            credit -= 1
            text_afisare.text = "Necastigator"
            // c + n + n
        }else if((valoare1 == 2)&&(valoare2 == 1)&&(valoare3 == 1)){
            credit += 5
            text_afisare.text = "5 PUNCTE"
            // m + c + c
        }else if((valoare1 == 2)&&(valoare2 == 1)&&(valoare3 == 2)){
            credit -= 1
            text_afisare.text = "Necastigator"
            // m + c + m
        }else if((valoare1 == 2)&&(valoare2 == 1)&&(valoare3 == 3)){
            credit -= 1
            text_afisare.text = "Necastigator"
            // m + c + n
        }else if((valoare1 == 2)&&(valoare2 == 2)&&(valoare3 == 1)){
            credit -= 1
            text_afisare.text = "Necastigator"
            // m + m + c
        }else if((valoare1 == 2)&&(valoare2 == 2)&&(valoare3 == 2)){
            credit -= 1
            text_afisare.text = "Necastigator"
            // m + m + m
        }else if((valoare1 == 2)&&(valoare2 == 2)&&(valoare3 == 3)){
            credit -= 1
            text_afisare.text = "Necastigator"
        }else if((valoare1 == 2)&&(valoare2 == 3)&&(valoare3 == 1)){
            credit -= 1
            text_afisare.text = "Necastigator"
        }else if((valoare1 == 2)&&(valoare2 == 3)&&(valoare3 == 2)){
            credit -= 1
            text_afisare.text = "Necastigator"
        }else if((valoare1 == 2)&&(valoare2 == 3)&&(valoare3 == 3)){
            credit -= 1
            text_afisare.text = "Necastigator"
        }else if((valoare1 == 3)&&(valoare2 == 1)&&(valoare3 == 1)){
            credit -= 1
            text_afisare.text = "Necastigator"
        }else if((valoare1 == 3)&&(valoare2 == 1)&&(valoare3 == 2)){
            credit -= 1
            text_afisare.text = "Necastigator"
        }else if((valoare1 == 3)&&(valoare2 == 1)&&(valoare3 == 3)){
            credit -= 1
            text_afisare.text = "Necastigator"
        }else if((valoare1 == 3)&&(valoare2 == 2)&&(valoare3 == 1)){
            credit -= 1
            text_afisare.text = "Necastigator"
        }else if((valoare1 == 3)&&(valoare2 == 2)&&(valoare3 == 2)){
            credit -= 1
            text_afisare.text = "Necastigator"
        }else if((valoare1 == 3)&&(valoare2 == 2)&&(valoare3 == 3)){
            credit -= 1
            text_afisare.text = "Necastigator"
        }else if((valoare1 == 3)&&(valoare2 == 3)&&(valoare3 == 1)){
            credit -= 1
            text_afisare.text = "Necastigator"
        }else if((valoare1 == 3)&&(valoare2 == 3)&&(valoare3 == 2)){
            credit -= 1
            text_afisare.text = "Necastigator"
        }else if((valoare1 == 3)&&(valoare2 == 3)&&(valoare3 == 3)){
            credit -= 5
            text_afisare.text = "Necastigator"
        }
    }
    func roteste1(){
        valoare1 = Int.random(in: 1...3)
        if (valoare1 == 1){
            casuta1.image = UIImage(named: "septar")
        }else if(valoare1 == 2){
            casuta1.image = UIImage(named: "capsuna")
        }else if(valoare1 == 3){
            casuta1.image = UIImage(named: "tomberon")
        }
    }
    func roteste2(){
        valoare2 = Int.random(in: 1...3)
        if (valoare2 == 1){
            casuta2.image = UIImage(named: "septar")
        }else if(valoare2 == 2){
            casuta2.image = UIImage(named: "capsuna")
        }else if(valoare2 == 3){
            casuta2.image = UIImage(named: "tomberon")
        }
    }
    func roteste3(){
        valoare3 = Int.random(in: 1...3)
        if (valoare3 == 1){
            casuta3.image = UIImage(named: "septar")
        }else if(valoare3 == 2){
            casuta3.image = UIImage(named: "capsuna")
        }else if(valoare3 == 3){
            casuta3.image = UIImage(named: "tomberon")
        }
    }
    //resetare
    @IBAction func reseteazaScor(_ sender: Any) {
        credit = 10;
        afisare_credit.text = "\(credit)"
        btnResetare.isHidden = true
        btnResetare.isEnabled = false
    }
    
    //audio
    
    @IBAction func pause_song(_ sender: Any) {
        if player != nil {
                    player.stop()
                    player = nil
                } else {
                    playSound()
                }
    }
    
    func playSound() {
           let url = Bundle.main.url(forResource: "jocurile_de_noroc", withExtension: "mp3")
           player = try! AVAudioPlayer(contentsOf: url!)
           player.play()
        }
}

